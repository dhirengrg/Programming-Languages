import re
import string
import os.path
from os import path

#Call all item function from the file in a read only mode
def CountAll():
    text = open("CS210_Project_Three_Input_File.txt", "r")

    #Create an empty dictionary to store "found" words
    dictionary = dict()

    #Check each line of the input file
    for line in text:
        #remove spaces and lower chase new line character
        line = line.strip()
        word = line.lower()
        
       #chekching words
        if word in dictionary:
            dictionary[word] = dictionary[word] + 1
        else:
            dictionary[word] = 1

    #Print all items
    for key in list (dictionary.keys()):
        print(key.capitalize(), ":", dictionary[key])
    text.close()
    
    #call this fucntion for specific item and pass the user input into the file
def CountInstances(specificItem):

    #Convert lower case for specific item input by user
    specificItem = specificItem.lower()
    text = open("CS210_Project_Three_Input_File.txt", "r")

    #varible for word count for item that are found in file
    wordCount = 0
    for line in text:
        line = line.strip()
        word = line.lower()
        if word == specificItem:
            wordCount += 1 
    return wordCount
    text.close()

    #call thsi function to count the frequency of the data and create the frequency.dat file for histogram
def CollectData():
    text = open("CS210_Project_Three_Input_File.txt", "r")
    frequency = open("frequency.dat", "w")
    dictionary = dict()
    for line in text:
        line = line.strip()
        word = line.lower()
        if word in dictionary:
            dictionary[word] = dictionary[word] + 1
        else:
            dictionary[word] = 1

    #Write each key and value pair to frequency.dat
    for key in list (dictionary.keys()):
        #Format the key-value pair as strings followed by a newline.
        frequency.write(str(key.capitalize()) + " " + str(dictionary[key]) + "\n")

    #Close the opened files
    text.close()
    frequency.close()
