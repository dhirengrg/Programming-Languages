#include <Python.h>
#include <iostream>
#include <iomanip>
#define NOMINMAX
#include <Windows.h>
#undef NOMINMAX
#include <cmath>
#include <string>
#include <fstream>

using namespace std;

/*
Description:
        To call this function, simply pass the function name in Python that you wish to call.
Example:
        callProcedure("printsomething");
Output:
        Python will print on the screen: Hello from python!
Return:
        None
*/
void CallProcedure(string pName)
{
    char* procname = new char[pName.length() + 1];
    std::strcpy(procname, pName.c_str());

    Py_Initialize();
    PyObject* my_module = PyImport_ImportModule("PythonCode");
    PyErr_Print();
    PyObject* my_function = PyObject_GetAttrString(my_module, procname);
    PyObject* my_result = PyObject_CallObject(my_function, NULL);
    Py_Finalize();

    delete[] procname;
}


/*
Description:
        To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
        int x = callIntFunc("PrintMe","Test");
Output:
        Python will print on the screen:
                You sent me: Test
Return:
        100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
    char* procname = new char[proc.length() + 1];
    std::strcpy(procname, proc.c_str());

    char* paramval = new char[param.length() + 1];
    std::strcpy(paramval, param.c_str());


    PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
    // Initialize the Python Interpreter
    Py_Initialize();
    // Build the name object
    pName = PyUnicode_FromString((char*)"PythonCode");
    // Load the module object
    pModule = PyImport_Import(pName);
    // pDict is a borrowed reference 
    pDict = PyModule_GetDict(pModule);
    // pFunc is also a borrowed reference 
    pFunc = PyDict_GetItemString(pDict, procname);
    if (PyCallable_Check(pFunc))
    {
        pValue = Py_BuildValue("(z)", paramval);
        PyErr_Print();
        presult = PyObject_CallObject(pFunc, pValue);
        PyErr_Print();
    }
    else
    {
        PyErr_Print();
    }
    //printf("Result is %d\n", _PyLong_AsInt(presult));
    Py_DECREF(pValue);
    // Clean up
    Py_DECREF(pModule);
    Py_DECREF(pName);
    // Finish the Python Interpreter
    Py_Finalize();

    // clean 
    delete[] procname;
    delete[] paramval;


    return _PyLong_AsInt(presult);
}


/*
Description:
        To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
        int x = callIntFunc("doublevalue",5);
Return:
        25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
    char* procname = new char[proc.length() + 1];
    std::strcpy(procname, proc.c_str());

    PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
    // Initialize the Python Interpreter
    Py_Initialize();
    // Build the name object
    pName = PyUnicode_FromString((char*)"PythonCode");
    // Load the module object
    pModule = PyImport_Import(pName);
    // pDict is a borrowed reference 
    pDict = PyModule_GetDict(pModule);
    // pFunc is also a borrowed reference 
    pFunc = PyDict_GetItemString(pDict, procname);
    if (PyCallable_Check(pFunc))
    {
        pValue = Py_BuildValue("(i)", param);
        PyErr_Print();
        presult = PyObject_CallObject(pFunc, pValue);
        PyErr_Print();
    }
    else
    {
        PyErr_Print();
    }
    //printf("Result is %d\n", _PyLong_AsInt(presult));
    Py_DECREF(pValue);
    // Clean up
    Py_DECREF(pModule);
    Py_DECREF(pName);
    // Finish the Python Interpreter
    Py_Finalize();

    // clean 
    delete[] procname;

    return _PyLong_AsInt(presult);
}
//void function
void option() {

    //Initialized variables
    int listLoop = 0;                  
    int itemNameCount = 0;            
    int itemQuantity = 0;       
    string specificItem;             
    string itemName;                  
    string greenColor = "\033[42m";       //Set background color green for the histogram asterisks
    string defaultColor = "\033[0m";   //Setting this difault color helps to set up display histogram background color
    ifstream fileInput;                   //Open ifstream for file

    while (listLoop != 4) {

        //Prompt user input options
       cout << "[1] List of All Items Purchased" <<endl;
       cout << "[2] Specific Item Purchased" <<endl;
       cout << "[3] Create a Histogram of All Items Purchased"<<endl;
       cout << "[4] Exit" <<endl;
       cin >> listLoop;

        //validate user input and promt again or continue
            while (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');//ignores maximum number of characters
            cout << "Invalid Option." << endl;
            cout << "Please Input Options 1, 2, 3, or 4." << endl;
           cin >> listLoop;
        }

        switch (listLoop) {
        case 1:
            system("CLS");          //Clear the screen
            cout << "Your Purchased Items:" << endl;
            CallProcedure("CountAll");        
            cout <<endl;        
            break;
        case 2:
            system("CLS");
            cout << "Type Specific Item You Purchased" <<endl;
            cin >> specificItem;
            
               //Call Python function for count number of times purchased with the specific item.
                itemNameCount = callIntFunc("CountInstances", specificItem);
                cout << endl << specificItem << " " << itemNameCount << endl << endl;
              break;
        case 3:
            system("CLS");                                        
            CallProcedure("CollectData");         
            fileInput.open("frequency.dat");        //Open frequency.dat

            fileInput >> itemName;                         
            fileInput >> itemQuantity;                       
            
            while (!fileInput.fail()) {
                //Set text color to the default white
               cout << defaultColor;

                //Print items for histogram
                cout <<setw(14) <<left << itemName <<setw(6);

                //histogram background color 
                cout << greenColor;

                //print number for histogram
                for (int i = 0; i < itemQuantity; i++) {
                    cout <<right << i+1;
                }
                cout <<endl;
                fileInput >> itemName;
                fileInput >> itemQuantity;
            }

            //Close frequency.dat, reset font color, then break
            fileInput.close();
           cout << defaultColor << endl;
            break;
        case 4:
            cout << "Thank You for Using Corner Grocer." << endl;
            return;

            //for default case print invalid message and prompt options again
        default:
            cout << "Invalid Option." << endl;
            cout << "Please Input Options 1, 2, 3, or 4." << endl;
            cout <<endl;
            break;
        }
    }
}

int main()
{
    option();

}
